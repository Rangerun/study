package demo

//var DemoCommand = &cobra.Command{
//	Use:   "demo",
//	Short: "demo",
//	RunE: func(c *cobra.Command, args []string) error {
//		container := util.GetContainer(c.Root())
//		log.Println(container)
//		return nil
//	},
//}
