package demo

type UserModel struct {
	UserId int
	Name   string
	Age    int
}
