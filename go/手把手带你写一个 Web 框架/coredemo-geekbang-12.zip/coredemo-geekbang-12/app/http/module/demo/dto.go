package demo

type UserDTO struct {
	ID   int    `json:"id"`
	Name string `json:"name"`
}
